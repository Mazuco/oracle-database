--------------------------------------------------------------------------------------
-- Cria��o de usu�rios

-- xpto_create_user.sql
--------------------------------------------------------------------

-- cria��o de um novo usu�rio
CREATE USER XPTO IDENTIFIED BY abcsenha;

-- dando dos grants
GRANT CONNECT, RESOURCE, DBA TO XPTO;
