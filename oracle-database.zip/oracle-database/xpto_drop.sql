--------------------------------------------------------------------------------------
-- Remo��o de tabelas

-- xpto_drop.sql

--------------------------------------------------------------------------------------
DROP TABLE xpto.itens_pedidos;  
DROP TABLE xpto.pedidos;
DROP TABLE xpto.inventarios;
DROP TABLE xpto.produtos;
DROP TABLE xpto.categoria_produtos;
DROP TABLE xpto.Armazens;
DROP TABLE xpto.funcionarios;
DROP TABLE xpto.contatos;
DROP TABLE xpto.clientes;
DROP TABLE xpto.locais;
DROP TABLE xpto.paises;
DROP TABLE xpto.continente;
